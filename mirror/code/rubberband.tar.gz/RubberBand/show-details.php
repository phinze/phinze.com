<?
$dodge = "yes";
include('adminheader.php');
echo "<h3>Show Details</h3>";

// CONNECT
$dbh=mysql_connect ("localhost", $db_user, $db_pass) or die ('I cannot connect to the database because: ' . mysql_error());
mysql_select_db ($db_name) or die( "Unable to select database");

$months = array(1 => "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");

$query = "SELECT * FROM " . $pre . "_shows WHERE ID=" . $z;
$result = mysql_query($query);

$name = mysql_result($result,0,"name");
$namelink = mysql_result($result,0,"namelink");
$location = mysql_result($result,0,"location");
$others = mysql_result($result,0,"others");
$price = mysql_result($result,0,"price");

$datetime = mysql_result($result,0,"datetime");
$month = substr($datetime,0,2);
$date = substr($datetime,2,2);
$hour = substr($datetime,4,2);
$minute = substr($datetime,6,2);

$ampm = "am";
if ($hour > 12) {$hour = $hour - 12; $ampm = "pm";} // Return to 12-hour time
if (substr($month,0,1) == "0") {$month = substr($month,1,1);} // Remove leading zeros for array
if (substr($hour,0,1) == "0") {$hour = substr($hour,1,1);} // Remove leading zeros from hour

echo "<b>Date:</b> " . $months[$month] . " " . $date . "<br>
<b>Venue Name:</b> " . $name . "<br>
<b>Venue URL:</b> <a href=\"" . $namelink . "\" target=\"_blank\">" . $namelink . "</a><br>
<b>Time:</b> " . $hour . ":" . $minute . " " . $ampm . "<br>
<b>Where:</b> " . $location . "<br>
<b>With:</b> " . $others . "<br>
<b>Price:</b> " . $price . "<br>
<a href=\"javascript: window.close()\">Close this window</a>.";

mysql_close;
include('adminfooter.php');
?>