<?
include('adminheader.php');

//start the session
session_start();

//check to make sure the session variable is registered
if(session_is_registered('username')){

//session variable is registered, the user is ready to logout
session_unset();
session_destroy();

echo "You are now logged out.<br><br><a href=\"index.html\">Back to the login page.</a>";
}

else{
//the session variable isn't registered, the user shouldn't even be on this page
echo "<a href=\"" . $admin_url . "index.html\">Click here to login</a>.";
}

include('adminfooter.php');
?>