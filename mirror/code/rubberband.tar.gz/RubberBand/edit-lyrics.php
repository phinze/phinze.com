<?
$dodge = "yes";
error_reporting(E_ERROR | E_PARSE);
include('adminheader.php');
echo "<h2>Edit Lyrics</h2>";

// CONNECT
$dbh=mysql_connect ("localhost", $db_user, $db_pass) or die ('I cannot connect to the database because: ' . mysql_error());
mysql_select_db ($db_name) or die( "Unable to select database");

if ($submit) {

	// FIELDS NOT MISSING (YOU WIN)
	if ($lyricsexist == "true") {
		$query = "UPDATE " . $pre . "_lyrics SET lyrics='" . $lyrics . "' WHERE ID=" . $id;
		mysql_query($query);
		echo "Changes saved.<br><br>
		<a href=\"javascript:window.close();\">Close window</a>.";
	} else {
		$query = "INSERT INTO " . $pre . "_lyrics VALUES ('', '" . $parent . "','" . $lyrics . "')";
		mysql_query($query);
		echo "Lyrics Added.<br><br>
		<a href=\"javascript:window.close();\">Close window</a>.";
     }

} else {

$query = "SELECT * FROM " . $pre . "_lyrics WHERE parent=" . $song;
$result = mysql_query($query);
$id = mysql_result($result,0,"id");
if (empty($id)) {$lyricsexist = "false";} else {$lyricsexist = "true";}
echo $lyricsexist;
$lyrics = mysql_result($result,0,"lyrics");

// Use $song to get song title from _songs
$song_query = "SELECT * FROM " . $pre . "_songs WHERE ID=" . $song;
$song_result = mysql_query($song_query);
$songtitle = mysql_result($song_result,0,"title");

echo "<h4>" . $songtitle . "</h4><br><br>
Edit whatever you want.
<form method=\"post\">
<input type=\"hidden\" name=\"id\" value=\"" . $id . "\">
<input type=\"hidden\" name=\"parent\" value=\"" . $song . "\">
<input type=\"hidden\" name=\"lyricsexist\" value=\"" . $lyricsexist . "\">
<table class=\"none\">
<tr><td valign=top><b>Lyrics:</b></td><td><textarea name=\"lyrics\" rows=12 cols=70>" . $lyrics . "</textarea></td></tr>
<tr><td>&nbsp;</td><td><input name=\"submit\" type=\"submit\" value=\"Post\" class=\"button\"></form></td></tr>
<tr><td>&nbsp;</td><td><form method=\"post\" action=\"javascript:window.close();\"><input type=\"submit\" value=\"Cancel\" class=\"button\"></form></td></tr></table>
";
}

mysql_close;
include('adminfooter.php');
?>