<?

include('adminheader.php');

echo "<h2>Edit Post</h2>";



// CONNECT

$dbh=mysql_connect ("localhost", $db_user, $db_pass) or die ('I cannot connect to the database because: ' . mysql_error());

mysql_select_db ($db_name) or die( "Unable to select database");



$months = array(1 => "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");



if ($submit) {



if ($title == "" || $body == "") {

// FIELDS MISSING (YOU SUCK)



echo "You forgot to fill in all the fields.

<br><br>

<form method=\"post\">

<table class=\"none\"><tr><td><b>Title:</b></td><td><input name=\"title\" value=\"" . $title . "\" size=\"40\"></td></tr>

<tr><td valign=top><b>Body:</b></td><td><textarea name=\"body\" rows=12 cols=70>" . $body . "</textarea></td></tr>

<tr><td>&nbsp;</td><td><input name=\"submit\" type=\"submit\" value=\"Post\" class=\"button\"></form></td></tr>

<tr><td>&nbsp;</td><td><form method=\"post\" action=\"list-news.php\"><input type=\"submit\" value=\"Cancel\" class=\"button\"></form></td></tr></table>

";



} else {

// FIELDS NOT MISSING (YOU WIN)



$query = "UPDATE " . $pre . "_news SET Title='" . $title . "', Body='" . $body . "' WHERE ID=" . $id;

mysql_query($query);



echo "Changes saved.<br><br>

<a href=\"list-news.php\">Back to news</a>.";

}



} else {



$query = "SELECT * FROM " . $pre . "_news WHERE ID=" . $id;

$result = mysql_query($query);



$title = mysql_result($result,0,"title");

$body = mysql_result($result,0,"body");

$author = mysql_result($result,0,"author");



$datetime = mysql_result($result,0,"datetime");

$year = substr($datetime,0,4);

$month = substr($datetime,5,2);

$date = substr($datetime,8,2);

$hour = substr($datetime,11,2);

$minute = substr($datetime,14,2);



$ampm = "am";

if ($hour > 12) {$hour = $hour - 12; $ampm = "pm";} // Return to 12-hour time

if (substr($month,0,1) == "0") {$month = substr($month,1,1);} // Remove leading zeros for array

if (substr($hour,0,1) == "0") {$hour = substr($hour,1,1);} // Remove leading zeros from hour



echo "Edit whatever you want.

<br><br><b>Author:</b> " . $author . "<br>

<b>Date:</b> " . $months[$month] . " " . $date . ", " . $year . "<br>

<b>Time:</b> " . $hour . ":" . $minute . " " . $ampm . "

<form method=\"post\">

<table class=\"none\"><tr><td><b>Title:</b></td><td><input name=\"title\" value=\"" . $title . "\" size=\"40\"></td></tr>

<tr><td valign=top><b>Body:</b></td><td><textarea name=\"body\" rows=12 cols=70>" . $body . "</textarea></td></tr>

<tr><td>&nbsp;</td><td><input name=\"submit\" type=\"submit\" value=\"Post\" class=\"button\"></form></td></tr>

<tr><td>&nbsp;</td><td><form method=\"post\" action=\"list-news.php\"><input type=\"submit\" value=\"Cancel\" class=\"button\"></form></td></tr></table>

";

}



mysql_close;

include('adminfooter.php');

?>