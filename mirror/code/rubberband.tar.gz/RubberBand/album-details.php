<?
$dodge = "yes";
include('adminheader.php');
echo "<h3>Album Details</h3>";

// CONNECT
$dbh=mysql_connect ("localhost", $db_user, $db_pass) or die ('I cannot connect to the database because: ' . mysql_error());
mysql_select_db ($db_name) or die( "Unable to select database");

$query = "SELECT * FROM " . $pre . "_albums WHERE ID=" . $z;
$result = mysql_query($query);

$album = mysql_result($result,0,"album");
$description = mysql_result($result,0,"description");

echo "<h2>" . $album . "</h2>
<br><div style=\"border: 1px solid white; margin: 5px 15px 1px 15px; padding: 3px;\">" . $description . "</div><br><br>
<table class=\"none\" cellspacing=1 cellpadding=1><tr><td><b>#</b></td><td><b>Title</b></td><td><b>Featuring</b></td><td>&nbsp;</td></tr>";

$query = "SELECT * FROM " . $pre . "_songs WHERE Parent=" . $z . " ORDER BY TrackNum";
$result = mysql_query($query);
$totalnum = mysql_numrows($result);

$i=0; while ($i < $totalnum) {

$song_query = "SELECT * FROM " . $pre . "_lyrics WHERE Parent=" . mysql_result($result,$i,"id");
$song_result = mysql_query($song_query);
$mp3_query = "SELECT * FROM " . $pre . "_mp3s WHERE Parent=" . mysql_result($result,$i,"id");
$mp3_result = mysql_query($mp3_query);

echo "<tr>
<td>" . mysql_result($result,$i,"tracknum") . "</td>
<td>" . mysql_result($result,$i,"title") . "</td>
<td>" . mysql_result($result,$i,"featuring") . "</td>
<td>";
if (!empty($song_result)) {echo "<a href=\"../lyrics.php?song=" . mysql_result($result,$i,"id") . "\">lyrics</a> ";}
if (!empty($mp3_result)) {echo "<a href=\"../mp3.php?song=" . mysql_result($result,$i,"id") . "\">mp3</a>";}
echo "</td></tr>";
++$i;}

echo "</table><br><br><a href=\"javascript: window.close()\">Close this window</a>.";

mysql_close;
include('adminfooter.php');
?>