<?
include('adminheader.php');
echo "<h2>Links</h2>";

// CONNECT
$dbh=mysql_connect ("localhost", $db_user, $db_pass) or die ('I cannot connect to the database because: ' . mysql_error());
mysql_select_db ($db_name) or die( "Unable to select database");

// ---Get list of already used categories
$query = "SELECT DISTINCT Category FROM " . $pre . "_links ORDER BY Category";
$result = mysql_query($query);
$totalnum = mysql_numrows($result);

$i = 0; while ($i < $totalnum) {
$used_categories[$i] = mysql_result($result,$i,"category");
++$i;}

// ---Get list of links
$query = "SELECT * FROM " . $pre . "_links ORDER BY Category,ID";
$result = mysql_query($query);
$totalnum = mysql_numrows($result);

echo "<table border=1 cellspacing=1 cellpadding=1>
<tr><td><b>Category</b></td><td><b>Link</b></td><td><b>Description</b></td><td>&nbsp;</td></tr>";

$i=0; while ($i < $totalnum) {
echo "<tr>
<td>" . mysql_result($result,$i,"category") . "
<td><a href=\"" . mysql_result($result,$i,"url") . "\">" . mysql_result($result,$i,"name") . "</a></td>
<td>" . mysql_result($result,$i,"description") . "</td>
<td><a href=\"edit-link.php?id=" . mysql_result($result,$i,"id") . "\">Edit</a> <a href=\"delete-link.php?id=" . mysql_result($result,$i,"id") . "\">Delete</a></td>
</tr>";
$i++;
}
echo "</table>

<br><br>
<form method=\"post\" action=\"add-link.php\">
<table border=0 cellspacing=0 cellpadding=0 style=\"width: 300px;\">
<tr><td colspan=2><div align=center><b>Add New Link:</b></div></td></tr>
<tr><td><div align=right>URL:</div></td><td><input type=\"text\" name=\"url\" value=\"http://\" size=25></td></tr>
<tr><td><div align=right>Link Text:</div></td><td><input type=\"text\" name=\"name\" size=25></td></tr>
<tr><td><div align=right>Description:</div></td><td><input type=\"text\" name=\"description\" size=25></td></tr>
<tr><td><div align=right>Category:</div></td><td>Previously used:
<select name=\"category\"><option value=\"(default)\">(default)</option>";

foreach ($used_categories as $value) {
echo "<option value=\"" . $value . "\">" . $value . "</option>";}

echo "</select><br>or new: <input type=\"text\" name=\"new_category\" size=17>
</td></tr>
<tr><td colspan=2><div align=center><input type=\"submit\" name=\"submit\" value=\"Add Link\"></div></td></tr></table></form>";

mysql_close;
include('adminfooter.php');
?>