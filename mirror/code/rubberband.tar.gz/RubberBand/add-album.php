<?
include('adminheader.php');
echo "<h2>Add Album</h2>";

if ($_POST['submit']) {
if ($_POST['album'] == "" || $_POST['description'] == "") {
// FIELDS NOT FILLED - YOU SUCK!
echo "You have not filled in all the fields.<br><br>NOTE: if you want to line break (go to the next line) you must put <b>&lt;br&gt;</b> at the end of the previous line.</b>
<form method=\"post\">
<input type=\"hidden\" name=\"tracks\" value=\"" . $tracks . "\">
<table class=\"none\"><tr><td><b>Album Title:</b></td><td><input name=\"album\" value=\"" . $album . "\" size=\"40\"></td></tr>
<tr><td valign=top><b>Description:</b></td><td><textarea name=\"description\" rows=12 cols=70>" . $description . "</textarea></td></tr>
<tr><td>&nbsp;</td><td><input name=\"submit\" type=\"submit\" value=\"Add Album\" class=\"button\"></form></td></tr>
<tr><td>&nbsp;</td><td><form method=\"post\" action=\"list-albums.php\"><input type=\"submit\" value=\"Cancel\" class=\"button\"></form></td></tr></table>";
} else {
// FIELDS FILLED - YOU POST!

// CONNECT
$dbh=mysql_connect ("localhost", $db_user, $db_pass) or die ('I cannot connect to the database because: ' . mysql_error());
mysql_select_db ($db_name) or die( "Unable to select database");

// Get last used album ordernum
$query = "SELECT ordernum FROM " . $pre . "_albums ORDER BY ordernum DESC LIMIT 1";
$result = mysql_query($query);

$query = "INSERT INTO " . $pre . "_albums VALUES ('','" . $album . "','" . $description . "','" . (mysql_result($result,0,"ordernum") + 1) . "')";
mysql_query($query);

$query = "SELECT ID FROM " . $pre . "_albums ORDER BY ID DESC LIMIT 1";
$result = mysql_query($query);
$id = mysql_result($result,0,"id");

$i = 0;
while ($i < $tracks) {
$query = "INSERT INTO " . $pre . "_songs VALUES ('','" . $id . "','','','" . ($i + 1) . "')";
mysql_query($query);
$i++;}

echo "Album successfully added. . . <br><br>
<a href=\"edit-album.php?id=" . $id . "\">Continue. . . Add Songs</a>";

}
} else {
echo "NOTE: if you want to line break (go to the next line) you must put <b>&lt;br&gt;</b> at the end of the previous line.</b>
<form method=\"post\">
<input type=\"hidden\" name=\"tracks\" value=\"" . $tracks . "\">
<table class=\"none\"><tr><td><b>Album Title:</b></td><td><input name=\"album\" size=\"40\"></td></tr>
<tr><td valign=top><b>Description:</b></td><td><textarea name=\"description\" rows=12 cols=70></textarea></td></tr>
<tr><td>&nbsp;</td><td><input name=\"submit\" type=\"submit\" value=\"Add Album\" class=\"button\"></form></td></tr>
<tr><td>&nbsp;</td><td><form method=\"post\" action=\"list-albums.php\"><input type=\"submit\" value=\"Cancel\" class=\"button\"></form></td></tr></table>";
 }
mysql_close;

include('adminfooter.php');
