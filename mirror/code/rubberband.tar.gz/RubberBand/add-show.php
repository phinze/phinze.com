<?
include('adminheader.php');
echo "<h2>Add Show</h2>";

if ($submit) {

if ($name == "" || $name == "Venue Name" || $date == "" || $hour == "" || $minute == "" || $location == "" || $price == "") {
// FIELDS MISSING (YOU SUCK)

$month_selected[$month] = "selected";
$ampm_selected[$ampm] = "checked";
echo "You forgot to fill in all the fields.
<br><br>
<form method=\"post\">
<b>Name:</b> <input name=\"name\" value=\"" . $name . "\" size=\"25\"><br>
<b>Venue URL:</b> <input name=\"namelink\" value=\"" . $namelink . "\" size=\"25\"> <font color=red>[optional]</font><br>
<b>Month:</b>&nbsp;&nbsp;<select name=\"month\">
<option name=\"month\" value=\"01\" " . $month_selected[01] . ">January</option>
<option name=\"month\" value=\"02\" " . $month_selected[02] . ">February</option>
<option name=\"month\" value=\"03\" " . $month_selected[03] . ">March</option>
<option name=\"month\" value=\"04\" " . $month_selected[04] . ">April</option>
<option name=\"month\" value=\"05\" " . $month_selected[05] . ">May</option>
<option name=\"month\" value=\"06\" " . $month_selected[06] . ">June</option>
<option name=\"month\" value=\"07\" " . $month_selected[07] . ">July</option>
<option name=\"month\" value=\"08\" " . $month_selected[08] . ">August</option>
<option name=\"month\" value=\"09\" " . $month_selected[09] . ">September</option>
<option name=\"month\" value=\"10\" " . $month_selected[10] . ">October</option>
<option name=\"month\" value=\"11\" " . $month_selected[11] . ">November</option>
<option name=\"month\" value=\"12\" " . $month_selected[12] . ">December</option>
</select>&nbsp;&nbsp;<b>Date:</b>&nbsp;&nbsp;<input type=\"text\" name=\"date\" value=\"" . $date . "\" style=\"width: 20px;\" maxlength=2><BR>
<b>Time:</b>&nbsp;&nbsp;<input type=\"text\" name=\"hour\" value=\"" . $hour . "\" style=\"width: 20px; text-align:right;\" maxlength=2>&nbsp;&nbsp;:&nbsp;&nbsp;<input type=\"text\" name=\"minute\" value=\"" . $minute . "\" style=\"width: 20px;\" maxlength=2>&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"radio\" name=\"ampm\" value=\"1\" " . $ampm_selected[1] . "> AM &nbsp;&nbsp;<input type=\"radio\" name=\"ampm\" value=\"2\"  " . $ampm_selected[2] . "> PM<BR>
<br>
<b>Where (include address):</b><br>
&nbsp;&nbsp;&nbsp;&nbsp;Timmy's House&lt;br&gt;<br>
&nbsp;&nbsp;&nbsp;&nbsp;123 Fake St.&lt;br&gt;<br>
&nbsp;&nbsp;&nbsp;&nbsp;Corner of Bluemound and Fake<br>
<textarea name=\"location\" rows=4 cols=30>" . $location . "</textarea><br>
<b>With (other bands):</b> <font color=red>[optional]</font><br>
&nbsp;&nbsp;&nbsp;&nbsp;KISS&lt;br&gt;<br>
&nbsp;&nbsp;&nbsp;&nbsp;AC/DC&lt;br&gt;<br>
&nbsp;&nbsp;&nbsp;&nbsp;The Scumfucks<br>
<textarea name=\"others\" rows=4 cols=30>" . $others . "</textarea><br>
<b>Price:</b>&nbsp;&nbsp;<INPUT name=\"price\" type=\"text\" value=\"" . $price . "\" size=\"5\">&nbsp;&nbsp;$4<br>
<input name=\"submit\" type=\"submit\" value=\"Try Again\">
</form>
<form method=\"post\" action=\"list-shows.php\">
<input type=\"submit\" value=\"Cancel\"></form>";


} else {
// FIELDS NOT MISSING (YOU WIN)

if ($ampm == "2") {$hour = $hour + 12;}   // If time is PM, add 12 to hours

while(strlen($date)!=2)$date="0".$date;      // Add leading zeros to #'s < 10
while(strlen($hour)!=2)$hour="0".$hour;
while(strlen($minute)!=2)$minute="0".$minute;
$datetime = $month . $date . $hour . $minute;   // Concatenate DateTime string

// CONNECT
$dbh=mysql_connect ("localhost", $db_user, $db_pass) or die ('I cannot connect to the database because: ' . mysql_error());
mysql_select_db ($db_name) or die( "Unable to select database");

$query = "INSERT INTO " . $pre . "_shows VALUES ('','" . $name . "','" . $namelink . "','" . $datetime . "','" . $location . "','" . $others ."','" . $price . "')";
mysql_query($query);

echo "Show successfully added.<br><br>
<a href=\"list-shows.php\">Back to shows</a>.";
}

} else {
?>

NOTE: if you want to line break (go to the next line) you must put <b>&lt;br&gt;</b> at the end of the previous line.</b>
<form method="post">
<b>Name:</b> <input name="name" value="Venue Name" size="25"><br>
<b>Venue URL:</b> <input name="namelink" value="http://" size="25"> <font color=red>[optional]</font><br>
<b>Month:</b>&nbsp;&nbsp;<select name="month">
<option name="month" value="01">January</option>
<option name="month" value="02">February</option>
<option name="month" value="03">March</option>
<option name="month" value="04">April</option>
<option name="month" value="05">May</option>
<option name="month" value="06">June</option>
<option name="month" value="07">July</option>
<option name="month" value="08">August</option>
<option name="month" value="09">September</option>
<option name="month" value="10">October</option>
<option name="month" value="11">November</option>
<option name="month" value="12">December</option>
</select>&nbsp;&nbsp;<b>Date:</b>&nbsp;&nbsp;<input type="text" name="date" style="width: 20px;" maxlength=2><BR>
<b>Time:</b>&nbsp;&nbsp;<input type="text" name="hour" value="8" style="width: 20px; text-align:right;" maxlength=2>&nbsp;&nbsp;:&nbsp;&nbsp;<input type="text" name="minute" value="00" style="width: 20px;" maxlength=2>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="ampm" value="1"> AM &nbsp;&nbsp;<input type="radio" name="ampm" value="2" checked> PM<BR>
<br>
<b>Where (include address):</b><br>
&nbsp;&nbsp;&nbsp;&nbsp;Timmy's House&lt;br&gt;<br>
&nbsp;&nbsp;&nbsp;&nbsp;123 Fake St.&lt;br&gt;<br>
&nbsp;&nbsp;&nbsp;&nbsp;Corner of Bluemound and Fake<br>
<textarea name="location" rows=4 cols=30></textarea><br>
<b>With (other bands):</b> <font color=red>[optional]</font><br>
&nbsp;&nbsp;&nbsp;&nbsp;KISS&lt;br&gt;<br>
&nbsp;&nbsp;&nbsp;&nbsp;AC/DC&lt;br&gt;<br>
&nbsp;&nbsp;&nbsp;&nbsp;The Scumfucks<br>
<textarea name="others" rows=4 cols=30></textarea><br>
<b>Price:</b>&nbsp;&nbsp;<INPUT name="price" type="text" size="5">&nbsp;&nbsp;$4<br>
<input name="submit" type="submit" value="Create">
</form>
<form method="post" action="list-shows.php">
<input type="submit" value="Cancel"></form>

<? }
mysql_close;

include('adminfooter.php');
?>