<?
$dodge = "yes";
error_reporting(E_ERROR | E_PARSE);
include('adminheader.php');
echo "<h2>Upload mp3</h2>";

// CONNECT
$dbh=mysql_connect ("localhost", $db_user, $db_pass) or die ('I cannot connect to the database because: ' . mysql_error());
mysql_select_db ($db_name) or die( "Unable to select database");

if ($upload) {
     // FIELDS NOT MISSING (YOU WIN)

     // First Upload the File

     $uploaddir = '../mp3/';
	$uploadfile = $uploaddir . $_FILES['userfile']['name'];

	print "<pre>";
	if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
	   print "File is valid, and was successfully uploaded. ";
	   print "Here's some more debugging info:\n";
	   print_r($_FILES);
	} else {
	   print "Possible file upload attack!  Here's some debugging info:\n";
	   print_r($_FILES);
	}
	print "</pre>";


     // Then update the mp3 database
	if ($nomp3 != "true" && $_FILES['userfile']['name']) {
		$query = "UPDATE " . $pre . "_mp3s SET filename='" . $_FILES['userfile']['name'] . "' WHERE ID=" . $id;
          echo $query;
		mysql_query($query);
		echo "Changes saved.<br><br>
		<a href=\"javascript:window.close();\">Close window</a>.";
	} else {
		$query = "INSERT INTO " . $pre . "_mp3s VALUES ('', '" . $parentsong . "','" . $songtitle . "','" . $_FILES['userfile']['name'] . "')";
          echo $query;
		mysql_query($query);
		echo "Mp3 Added.<br><br>
		<a href=\"javascript:window.close();\">Close window</a>.";
     }

} else {

$query = "SELECT * FROM " . $pre . "_mp3s WHERE parentsong=" . $song;
$result = mysql_query($query);
$id = mysql_result($result,0,"id");
$filename = mysql_result($result,0,"filename");
if (empty($id)) {$nomp3 = "true"; $mp3_message = "There is no mp3 uploaded for this song.<br><br>";} else {$mp3_message = "<b>" . $filename . "</b> is assigned to this song.<br><br>";}

// Use $song to get song title from _songs
$song_query = "SELECT * FROM " . $pre . "_songs WHERE ID=" . $song;
$song_result = mysql_query($song_query);
$songtitle = mysql_result($song_result,0,"title");
$songid = mysql_result($song_result,0,"id");

echo "<h4>" . $songtitle . "</h4><br>
" . $mp3_message . "
<form name=\"upload\" id=\"upload\" ENCTYPE=\"multipart/form-data\" method=\"post\">
  <input type=\"hidden\" name=\"nomp3\" value=\"" . $nomp3 . "\" />
  <input type=\"hidden\" name=\"id\" value=\"" . $id . "\" />
  <input type=\"hidden\" name=\"parentsong\" value=\"" . $songid . "\" />
  <input type=\"hidden\" name=\"songtitle\" value=\"" . $songtitle . "\" />
  <input type=\"hidden\" name=\"MAX_FILE_SIZE\" value=\"8000000\" />
  Upload mp3<input type=\"file\" id=\"userfile\" name=\"userfile\">
  <input onClick=\"changetitle()\" type=\"submit\" name=\"upload\" value=\"Upload\">
</form></td></tr>
<tr><td>&nbsp;</td><td><form method=\"post\" action=\"javascript:window.close();\"><input type=\"submit\" value=\"Cancel\" class=\"button\"></form></td></tr></table>
";
}

mysql_close;
include('adminfooter.php');
?>