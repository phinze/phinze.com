<?
include('adminheader.php');
echo "<h2>Add Story</h2>";

if ($submit) {
if ($title == "" || $body == "") {
// FIELDS NOT FILLED - YOU SUCK!
echo "You have not filled in all the fields.<br><br>NOTE: if you want to line break (go to the next line) you must put <b>&lt;br&gt;</b> at the end of the previous line.</b>
<form method=\"post\">
<table class=\"none\"><tr><td><b>Title:</b></td><td><input name=\"title\" value=\"" . $title . "\" size=\"40\"></td></tr>
<tr><td valign=top><b>Body:</b></td><td><textarea name=\"body\" rows=12 cols=70>" . $body . "</textarea></td></tr>
<tr><td>&nbsp;</td><td><input name=\"submit\" type=\"submit\" value=\"Post\" class=\"button\"></form></td></tr>
<tr><td>&nbsp;</td><td><form method=\"post\" action=\"list-stories.php\"><input type=\"submit\" value=\"Cancel\" class=\"button\"></form></td></tr></table>";
} else {
// FIELDS FILLED - YOU POST!

// CONNECT
$dbh=mysql_connect ("localhost", $db_user, $db_pass) or die ('I cannot connect to the database because: ' . mysql_error());
mysql_select_db ($db_name) or die( "Unable to select database");

$query = "INSERT INTO " . $pre . "_stories VALUES ('','" . $title . "','" . $body . "','" . $username . "','" . date("mdHi") . "')";
mysql_query($query);

echo "Story successfully added.<br><br><a href=\"list-stories.php\">Return to Stories</a>";

}
} else {
echo "NOTE: if you want to line break (go to the next line) you must put <b>&lt;br&gt;</b> at the end of the previous line.</b>
<form method=\"post\">
<table class=\"none\"><tr><td><b>Title:</b></td><td><input name=\"title\" size=\"40\"></td></tr>
<tr><td valign=top><b>Body:</b></td><td><textarea name=\"body\" rows=12 cols=70></textarea></td></tr>
<tr><td>&nbsp;</td><td><input name=\"submit\" type=\"submit\" value=\"Post\" class=\"button\"></form></td></tr>
<tr><td>&nbsp;</td><td><form method=\"post\" action=\"list-stories.php\"><input type=\"submit\" value=\"Cancel\" class=\"button\"></form></td></tr></table>";
 }
mysql_close;

include('adminfooter.php');
?>