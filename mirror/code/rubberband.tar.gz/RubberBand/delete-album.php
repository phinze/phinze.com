<?
include('adminheader.php');
echo "<h2>Delete Album</h2>";

// CONNECT
$dbh=mysql_connect ("localhost", $db_user, $db_pass) or die ('I cannot connect to the database because: ' . mysql_error());
mysql_select_db ($db_name) or die( "Unable to select database");

if ($submit) {
// CHECK IF CONFIRMED AND DELETE
if ($confirm1 && $confirm2 && $confirm3) {
// BOXES CHECKED; DELETE
$query = "DELETE FROM " . $pre . "_albums WHERE ID=" . $id . "";
mysql_query($query);

$query = "DELETE FROM " . $pre . "_songs WHERE Parent=" . $id . "";
mysql_query($query);

$query = "DELETE FROM " . $pre . "_lyrics WHERE Parent=" . $id . "";
mysql_query($query);

$query = "DELETE FROM " . $pre . "_mp3s WHERE Parent=" . $id . "";
mysql_query($query);

echo "Album successfully deleted.<br><br>
<a href=\"list-albums.php\">Back to albums</a>.";
} else {
// BOXES NOT CHECKED; RETURN
echo "All three boxes must be checked to confirm deletion of this album.<br><br>
<a href=\"javascript: history.back()\">Go back and try again</a>.";
}
} else {
// CONFIRM DELETION
$query = "SELECT * FROM " . $pre . "_albums WHERE ID=" . $id;
$result = mysql_query($query);

$album = mysql_result($result,0,"album");
$description = mysql_result($result,0,"description");

echo "<h3>" . $album . "</h3>
<br><div style=\"border: 1px solid white; margin: 5px 15px 1px 15px; padding: 3px;\">" . $description . "</div><br><br>
<table class=\"none\" cellspacing=1 cellpadding=1><tr><td><b>#</b></td><td><b>Title</b></td><td><b>Featuring</b></td><td>&nbsp;</td></tr>";

$query = "SELECT * FROM " . $pre . "_songs WHERE Parent=" . $id . " ORDER BY TrackNum";
$result = mysql_query($query);
$totalnum = mysql_numrows($result);

$i=0; while ($i < $totalnum) {

$song_query = "SELECT * FROM " . $pre . "_lyrics WHERE Parent=" . mysql_result($result,$i,"id");
$song_result = mysql_query($song_query);
$mp3_query = "SELECT * FROM " . $pre . "_mp3s WHERE Parent=" . mysql_result($result,$i,"id");
$mp3_result = mysql_query($mp3_query);

echo "<tr>
<td>" . mysql_result($result,$i,"tracknum") . "</td>
<td>" . mysql_result($result,$i,"title") . "</td>
<td>" . mysql_result($result,$i,"featuring") . "</td>
<td>";
if (!empty($song_result)) {echo "<a href=\"../lyrics.php?song=" . mysql_result($result,$i,"id") . "\">lyrics</a> ";}
if (!empty($mp3_result)) {echo "<a href=\"../mp3.php?song=" . mysql_result($result,$i,"id") . "\">mp3</a>";}
echo "</td></tr>";
++$i;}

echo "</table>
<form method=\"post\">
<b>Check all three boxes to confirm.</b>
<input type=\"checkbox\" name=\"confirm1\" value=\"1\"> --
<input type=\"checkbox\" name=\"confirm2\" value=\"2\"> --
<input type=\"checkbox\" name=\"confirm3\" value=\"3\"><br>
<input type=\"submit\" name=\"submit\" value=\"Delete\">
</form>
<form method=\"post\" action=\"list-albums.php\">
<input type=\"submit\" value=\"Cancel\"></form>
";


 }
mysql_close;
include('adminfooter.php');
?>