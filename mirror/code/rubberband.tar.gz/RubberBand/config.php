<?
// DECLARE MYSQL VARIABLES
$db_name = "dudeman_rubberband";
$db_user = "dudeman_thought";
$db_pass = "snowplow";
$pre = "thought";
$folder = "/ckt";
$admin_url = "http://www.cryptkickertrio.com/admin/";

$the_path = "";
?>