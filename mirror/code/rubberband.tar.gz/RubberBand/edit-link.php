<?
include('adminheader.php');
echo "<h2>Edit Link</h2>";

// ---Get list of already used categories
// CONNECT
$dbh=mysql_connect ("localhost", $db_user, $db_pass) or die ('I cannot connect to the database because: ' . mysql_error());
mysql_select_db ($db_name) or die( "Unable to select database");

$query = "SELECT DISTINCT Category FROM " . $pre . "_links ORDER BY Category";
$result = mysql_query($query);
$totalnum = mysql_numrows($result);

$i = 0; while ($i < $totalnum) {
$used_categories[$i] = mysql_result($result,$i,"category");
++$i;}


if ($submit) {

if ($url == "" || $url == "http://" || $name == "Venue Name") {
// FIELDS MISSING (YOU SUCK)

$selected[$category] = "selected";
echo "You didn't fill in all the required fields.
<br><br>
<form method=\"post\">
<input type=\"hidden\" name=\"id\" value=\"" . $id . "\">
<table border=0 cellspacing=0 cellpadding=0 style=\"width: 300px;\">
<tr><td colspan=2><div align=center><b>Add New Link:</b></div></td></tr>
<tr><td><div align=right>URL:</div></td><td><input type=\"text\" name=\"url\" value=\"" . $url . "\" size=25></td></tr>
<tr><td><div align=right>Link Text:</div></td><td><input type=\"text\" name=\"name\" value=\"" . $name . "\" size=25></td></tr>
<tr><td><div align=right>Description:</div></td><td><input type=\"text\" name=\"description\" value=\"" . $description . "\" size=25> <font color=red>[optional]</font></td></tr>
<tr><td><div align=right>Category:</div></td><td>Previously used:
<select name=\"category\"><option value=\"(default)\">(default)</option>";

foreach ($used_categories as $value) {
echo "<option value=\"" . $value . "\" " . $selected[$value] . ">" . $value . "</option>";}

echo "</select><br>or new: <input type=\"text\" name=\"new_category\" value=\"" . $new_category . "\"size=17>
</td></tr>
<tr><td colspan=2><div align=center><input type=\"submit\" name=\"submit\" value=\"Save Changes\"></div></td></tr></table></form>

<br><br><form method=\"post\" action=\"list-links.php\">
<input type=\"submit\" value=\"Cancel\"></form>";

} else {
// FIELDS NOT MISSING (YOU WIN)

// Determine category
if (empty($new_category)) {$category_write = $category;}
else {$category_write = $new_category;}

$query = "UPDATE " . $pre . "_links SET URL='" . $url . "', Name='" . $name . "', Description='" . $description . "', Category='" . $category_write . "' WHERE ID=" . $id;
mysql_query($query);

echo "Changes saved.<br><br>
<a href=\"list-links.php\">Back to links</a>.";
}

} else {

$query = "SELECT * FROM " . $pre . "_links WHERE ID=" . $id;
$result = mysql_query($query);

$url = mysql_result($result,0,"url");
$name = mysql_result($result,0,"name");
$description = mysql_result($result,0,"description");
$category = mysql_result($result,0,"category");
$selected[$category] = "selected";

echo "Edit whatever you want.
<br><br>
<form method=\"post\">
<input type=\"hidden\" name=\"id\" value=\"" . $id . "\">
<table border=0 cellspacing=0 cellpadding=0 style=\"width: 300px;\">
<tr><td colspan=2><div align=center><b>Add New Link:</b></div></td></tr>
<tr><td><div align=right>URL:</div></td><td><input type=\"text\" name=\"url\" value=\"" . $url . "\" size=25></td></tr>
<tr><td><div align=right>Link Text:</div></td><td><input type=\"text\" name=\"name\" value=\"" . $name . "\" size=25></td></tr>
<tr><td><div align=right>Description:</div></td><td><input type=\"text\" name=\"description\" value=\"" . $description . "\" size=25></td></tr>
<tr><td><div align=right>Category:</div></td><td>Previously used:
<select name=\"category\"><option value=\"(default)\">(default)</option>";

foreach ($used_categories as $value) {
echo "<option value=\"" . $value . "\" " . $selected[$value] . ">" . $value . "</option>";}

echo "</select><br>or new: <input type=\"text\" name=\"new_category\" value=\"" . $new_category . "\"size=17>
</td></tr>
<tr><td colspan=2><div align=center><input type=\"submit\" name=\"submit\" value=\"Save Changes\"></div></td></tr></table></form>

<br><br><form method=\"post\" action=\"list-links.php\">
<input type=\"submit\" value=\"Cancel\"></form>";
}

mysql_close;

include('adminfooter.php');
?>