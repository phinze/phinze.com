<?
include('adminheader.php');


if ($submit) {
$fp = fopen ("../motd.txt", "w");
fwrite ($fp, $the_msg);
fclose ($fp);
}

$fp = fopen("../motd.txt", "r");
$msg_load = fread($fp, filesize("../motd.txt"));
fclose ($fp);

?>

<table class="index" cellspacing=0 cellpadding=0>
<tr><td width=140><a href="list-shows.php" class="menu">Shows</a></td><td>Add, edit, delete upcoming shows.</td></tr>
<tr><td><a href="list-news.php" class="menu">News</a></td><td>Add, edit, delete band news.</td></tr>
<tr><td><a href="list-stories.php" class="menu">Stories</a></td><td>Add, edit, delete stories.</td></tr>
<tr><td><a href="list-links.php" class="menu">Links</a></td><td>Add, edit, delete links.</td></tr>
<tr><td><a href="list-albums.php" class="menu">Albums</a></td><td>Add, edit, delete music/lyrics.</td></tr>
<tr><td><a href="upload-gallery.php" class="menu">Gallery</a></td><td>Add/Delete pictures.</td></tr>
<tr><td><a href="list-users.php" class="menu">Users</a></td><td>Manage the users for rubber band.</td></tr>
<tr><td><a href="bios.php" class="menu">Bios</a></td><td>Manage band members' bios with <B>PIZZAZ</B>!</td></tr>
<tr><td><a href="logout.php" class="menu">Logout</a></td><td>Log out of rubber band.</td></tr>
</table>

<br><form name="motd" method="post"><b>Message of the Day:</b><br>
<textarea name="the_msg" cols=33 rows=5 style="padding: 3px; background-color: #333333; color: #ffffff;"><? echo stripslashes($msg_load) ?></textarea>
<br><input type="submit" name="submit" value="save message of the day"></form>

<?
include('adminfooter.php');
?>