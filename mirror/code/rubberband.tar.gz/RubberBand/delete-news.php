<?

include('adminheader.php');

echo "<h2>Delete Post</h2>";



// CONNECT

$dbh=mysql_connect ("localhost", $db_user, $db_pass) or die ('I cannot connect to the database because: ' . mysql_error());

mysql_select_db ($db_name) or die( "Unable to select database");



$months = array(1 => "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");



if ($submit) {

// CHECK IF CONFIRMED AND DELETE

if ($confirm1 && $confirm2 && $confirm3) {

// BOXES CHECKED; DELETE

$query = "DELETE FROM " . $pre . "_news WHERE ID=" . $id . "";

mysql_query($query);



echo "Post successfully deleted.<br><br>

<a href=\"list-news.php\">Back to news</a>.";

} else {

// BOXES NOT CHECKED; RETURN

echo "All three boxes must be checked to confirm deletion of this post.<br><br>

<a href=\"javascript: history.back()\">Go back and try again</a>.";

}

} else {

// CONFIRM DELETION

$query = "SELECT * FROM " . $pre . "_news WHERE ID=" . $id;

$result = mysql_query($query);



$title = mysql_result($result,0,"title");

$body = mysql_result($result,0,"body");

$author = mysql_result($result,0,"author");



$datetime = mysql_result($result,0,"datetime");

$year = substr($datetime,0,4);

$month = substr($datetime,5,2);

$date = substr($datetime,8,2);

$hour = substr($datetime,11,2);

$minute = substr($datetime,14,2);



$ampm = "am";

if ($hour > 12) {$hour = $hour - 12; $ampm = "pm";} // Return to 12-hour time

if (substr($month,0,1) == "0") {$month = substr($month,1,1);} // Remove leading zeros for array

if (substr($hour,0,1) == "0") {$hour = substr($hour,1,1);} // Remove leading zeros from hour



echo "<b>Are you sure you want to delete this post?</b><br><br>

<b>Date:</b> " . $months[$month] . " " . $date . ", " . $year . "<br>

<b>Time:</b> " . $hour . ":" . $minute . " " . $ampm . "<br><br>

<b>Title:</b> " . $title . "<br>

<div style=\"border: 1px solid white; margin: 5px 85px 1px 15px; padding: 3px;\">" . $body . "</div>

<br>

<form method=\"post\">

<b>Check all three boxes to confirm.</b>

<input type=\"checkbox\" name=\"confirm1\" value=\"1\"> --

<input type=\"checkbox\" name=\"confirm2\" value=\"2\"> --

<input type=\"checkbox\" name=\"confirm3\" value=\"3\"><br>

<input type=\"submit\" name=\"submit\" value=\"Delete\">

</form>

<form method=\"post\" action=\"list-news.php\">

<input type=\"submit\" value=\"Cancel\"></form>

";





 }

mysql_close;

include('adminfooter.php');

?>