<?
if ($dodge != "yes") {echo "</div>";}
echo "</body></html>";
?>