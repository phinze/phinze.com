<?

include('adminheader.php');

echo "<h2>News</h2>";



// CONNECT

$dbh=mysql_connect ("localhost", $db_user, $db_pass) or die ('I cannot connect to the database because: ' . mysql_error());

mysql_select_db ($db_name) or die( "Unable to select database");



$query = "SELECT * FROM " . $pre . "_news ORDER BY datetime DESC";

$result = mysql_query($query);

$totalnum = mysql_numrows($result);



echo "<table border=1 cellspacing=1 cellpadding=1>

<tr><td><b>Date</b></td><td><b>Title</b></td><td><b>Time</b></td><td><b>Preview</b></td><td>&nbsp;</td></tr>";



$i=0; while ($i < $totalnum) {

$datetime = mysql_result($result,$i,"datetime");

$year = substr($datetime,0,4);

$month = substr($datetime,5,2);

$date = substr($datetime,8,2);

$hour = substr($datetime,11,2);

$minute = substr($datetime,14,2);



$ampm = "am";

if ($hour > 12) {$hour = $hour - 12; $ampm = "pm";} // Return to 12-hour time

if (substr($month,0,1) == "0") {$month = substr($month,1,1);} // Remove leading zeros for array

if (substr($hour,0,1) == "0") {$hour = substr($hour,1,1);} // Remove leading zeros from hour



echo "<tr>

<td>" . $month . "-" . $date . ", " . $year . "</td>

<td><a href=\"javascript: newsdetails('" . mysql_result($result,$i,"id") . "');\" title=\"View post\">" . mysql_result($result,$i,"title") . "</a></td>

<td>" . $hour . ":" . $minute . " " . $ampm . "</td>

<td>" . strip_tags(substr(mysql_result($result,$i,"body"),0,200)) . ". . .</td>

<td><a href=\"edit-news.php?id=" . mysql_result($result,$i,"id") . "\">Edit</a> <a href=\"delete-news.php?id=" . mysql_result($result,$i,"id") . "\">Delete</a></td>

</tr>";

$i++;

}

echo "</table>



<br><form method=\"post\" action=\"add-news.php\">

<input type=\"submit\" value=\"    Post News    \"></form>";



mysql_close;

include('adminfooter.php');

?>