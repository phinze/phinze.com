<?
include("adminheader.php");
echo "<h2>Add Photo</h2>";
# *************************** UPLOAD SCRIPT ****************************
# Original opensource script and tutorial by Darren Beale
#  and located at http://www.phpbuilder.com/columns/bealers20000904.php3
# Password protect and other sundries by Karl of PyroKinetic Designs
# ****************************** ENJOY *********************************

if ($new_folder == "") { // Uploading to already existing folder
$the_path = "/home/dudeman/public_html" . $folder . "/photos/" . $upload_folder;
} else { // Create new folder
$new_path = "/home/dudeman/public_html" . $folder . "/photos/" . $new_folder;
mkdir($new_path, 0777);
chmod($new_path, 0777);
$the_path = $new_path;
}

function form($error=false) {
// Get list of existing folders
$handle=opendir('../photos');
$files = array("");
$i = 0;
while (false!==($file = readdir($handle))) // Loop through each valid file in the directory
{
if (!strpos($file, ".") && $file != ".." && $file != ".")
	{
   	  	$files[$i] = $file;
		++$i;
     }
}
closedir($handle);
$totalnum = $i;

global $PHP_SELF,$my_max_file_size;
    if ($error) echo $error . "<br><br>";
echo "<form ENCTYPE=\"multipart/form-data\" action=\"" . $PHP_SELF . "\" method=\"post\">
<input type=\"hidden\" name=\"task\" value=\"upload\">
<table class=\"none\" border=0 cellspacing=0 cellpadding=3>
<tr><td>Photo:</td><td><input name=\"the_file\" type=\"file\" size=\"35\"></td></tr>
<tr><td>Category:</td><td>Existing: <select name=\"upload_folder\">";
$i = 0;
while ($i < $totalnum) {
echo "<option value=\"" . $files[$i] . "\">" . $files[$i] . "</option>";
++$i;}
echo "</select><br>
OR New: <input type=\"text\" name=\"new_folder\" size=\"20\"></td></tr>
<tr><td colspan=2 align=center><input type=\"submit\" Value=\"Upload\"></td></tr></table>
</form>";
} # END form

if (!ereg("^4",phpversion())) {
    function in_array($needle,$haystack) { # we have this function in PHP4, so for you PHP3 people
        for ($i=0; $i < count($haystack); $i++) {
            if ($haystack[$i] == $needle) {
                return true;
            }
        }
    }
}

function validate_upload($the_file) {
global $my_max_file_size, $image_max_width, $image_max_height,$allowed_types,$the_file_type,$registered_types;
$start_error = "\n<b>Error:</b>\n<ul>";

    if ($the_file == "none") { # do we even have a file?

        $error .= "\n<li>You did not upload anything!</li>";

    } else { # check if we are allowed to upload this file_type

   /*     if (!in_array($the_file_type,$allowed_types)) {
                while ($type = current($allowed_types)) {
                  next($allowed_types);
            }
        }    */

     //   if (ereg("",$the_file_type) && (in_array($the_file_type,$allowed_types))) {

            $size = GetImageSize($the_file);
            list($foo,$width,$bar,$height) = explode("\"",$size[3]);

        /*    if ($width > $image_max_width) {
                $error .= "\n<li>Your image should be no wider than " .
                    $image_max_width . " Pixels</li>";
            }

            if ($height > $image_max_height) {
                $error .= "\n<li>Your image should be no higher than " .
                    $image_max_height . " Pixels</li>";
            }     */

    //    }

        if ($error) {
            $error = $start_error . $error . "\n</ul>";
            return $error;
        } else {
            return false;
        }
    }
 } # END validate_upload

function upload($the_file) {
global $the_path,$the_file_name;
    $error = validate_upload($the_file);
    if ($error) {
        form($error);
    } else { # cool, we can continue
        if (!@copy($the_file, $the_path . "/" . $the_file_name)) {
            form("\n<b>Something barfed, check the path to and ".
            "the permissions for the upload directory</b>");
        } else {
        	  chmod($the_path . "/" . $the_file_name, 0777);
            echo "<b>$the_file_name uploaded successfully.</b>";
            form();
        }
    }
} # END upload


switch($task) {
    case 'upload':
        upload($the_file);
    break;
    default:
        form();
}

echo "<h2>Delete Photos</h2>
<a href=\"../photos/images-delete.php\">Click here to delete photos</a>";

include("adminfooter.php");
?>