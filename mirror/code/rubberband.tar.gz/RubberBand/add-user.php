<?
include('adminheader.php');
echo "<h2>Add User</h2>";

// ---Get list of already used categories
// CONNECT
$dbh=mysql_connect ("localhost", $db_user, $db_pass) or die ('I cannot connect to the database because: ' . mysql_error());
mysql_select_db ($db_name) or die( "Unable to select database");

$query = "SELECT DISTINCT Category FROM " . $pre . "_users";
$result = mysql_query($query);

if ($submit) {

if ($name == "" || $pass == "" || $pass != $passcheck ) {
// FIELDS MISSING (YOU SUCK)

echo "You didn't fill in all the required fields.  Remember everything is case sensitive.
<br><br>
<form method=\"post\">
<table border=0 cellspacing=0 cellpadding=0 style=\"width: 300px;\">
<tr><td colspan=2><div align=center><b>Add New Link:</b></div></td></tr>
<tr><td><div align=right>Username:</div></td><td><input type=\"text\" name=\"name\" value=\"" . $name . "\" size=25></td></tr>
<tr><td><div align=right>Password:</div></td><td><input type=\"password\" name=\"pass\" value=\"" . $pass . "\" size=25></td></tr>
<tr><td><div align=right>Password Verify:</div></td><td><input type=\"password\" name=\"passcheck\" value=\"" . $passcheck . "\" size=25></td></tr>
";

echo "<tr><td colspan=2><div align=center><input type=\"submit\" name=\"submit\" value=\"Add User\"></div></td></tr></table></form>

<br><br><form method=\"post\" action=\"list-users.php\">
<input type=\"submit\" value=\"Cancel\"></form>";

} else {
// FIELDS NOT MISSING (YOU WIN)

$query = "INSERT INTO " . $pre . "_users VALUES ('" . $name . "','" . md5($pass) . "')";
mysql_query($query);

echo "User successfully added.<br><br>
<a href=\"list-users.php\">Back to users</a>.";
}

} else {

echo "Add in a brand new user. Remember <i>everything</i> is case sensitive.<br>
Also note that user name is what's placed as the \"author\" of everything you post, so capitalize your name.
<br><br>
<form method=\"post\">
<table border=0 cellspacing=0 cellpadding=0 style=\"width: 300px;\">
<tr><td colspan=2><div align=center><b>Add New User:</b></div></td></tr>
<tr><td><div align=right>Username:</div></td><td><input type=\"text\" name=\"name\" size=25></td></tr>
<tr><td><div align=right>Password:</div></td><td><input type=\"password\" name=\"pass\" size=25></td></tr>
<tr><td><div align=right>Password Verify:</div></td><td><input type=\"password\" name=\"passcheck\" size=25></td></tr>
";

echo "<tr><td colspan=2><div align=center><input type=\"submit\" name=\"submit\" value=\"Add User\"></div></td></tr></table></form>

<br><br><form method=\"post\" action=\"list-users.php\">
<input type=\"submit\" value=\"Cancel\"></form>";
}

mysql_close();

include('adminfooter.php');
?>