<?
$dodge = "yes";
include('adminheader.php');
echo "<h3>View Story</h3>";

// CONNECT
$dbh=mysql_connect ("localhost", $db_user, $db_pass) or die ('I cannot connect to the database because: ' . mysql_error());
mysql_select_db ($db_name) or die( "Unable to select database");

$months = array(1 => "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");

$query = "SELECT * FROM " . $pre . "_stories WHERE ID=" . $z;
$result = mysql_query($query);

$title = mysql_result($result,0,"title");
$body = mysql_result($result,0,"body");
$author = mysql_result($result,0,"author");

$datetime = mysql_result($result,0,"datetime");
$month = substr($datetime,0,2);
$date = substr($datetime,2,2);
$hour = substr($datetime,4,2);
$minute = substr($datetime,6,2);

$ampm = "am";
if ($hour > 12) {$hour = $hour - 12; $ampm = "pm";} // Return to 12-hour time
if (substr($month,0,1) == "0") {$month = substr($month,1,1);} // Remove leading zeros for array
if (substr($hour,0,1) == "0") {$hour = substr($hour,1,1);} // Remove leading zeros from hour

echo "<b>Date:</b> " . $months[$month] . " " . $date . "<br>
<b>Time:</b> " . $hour . ":" . $minute . " " . $ampm . "<br><br>
<b>Title:</b> " . $title . "<br>
<div style=\"border: 1px solid white; margin: 5px 15px 1px 15px; padding: 3px;\">" . $body . "</div>

<br><br><a href=\"javascript: window.close()\">Close this window</a>.";

mysql_close;
include('adminfooter.php');
?>