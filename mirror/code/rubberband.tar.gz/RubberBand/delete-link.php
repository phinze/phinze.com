<?
include('adminheader.php');
echo "<h2>Delete Link</h2>";

// CONNECT
$dbh=mysql_connect ("localhost", $db_user, $db_pass) or die ('I cannot connect to the database because: ' . mysql_error());
mysql_select_db ($db_name) or die( "Unable to select database");

if ($submit && $confirm == "yes") {
// CONFIRMED; DELETE
$query = "DELETE FROM " . $pre . "_links WHERE ID=" . $id . "";
mysql_query($query);

echo "Link successfully deleted.<br><br>
<a href=\"list-links.php\">Back to shows</a>.";
} else {
// CONFIRM DELETION
$query = "SELECT * FROM " . $pre . "_links WHERE ID=" . $id;
$result = mysql_query($query);

$url = mysql_result($result,0,"url");
$name = mysql_result($result,0,"name");
$description = mysql_result($result,0,"description");
$category = mysql_result($result,0,"category");

echo "<b>Are you sure you want to delete this link?</b><br><br>

<table border=0 cellspacing=0 cellpadding=0 style=\"width: 300px;\">
<tr><td><div align=right>URL:</div></td><td><a href=\"" . $url . "\">" . $url . "</a></td></tr>
<tr><td><div align=right>Link Text:</div></td><td>" . $name . "</td></tr>
<tr><td><div align=right>Description:</div></td><td>" . $description . "</td></tr>
<tr><td><div align=right>Category</div></td><td>" . $category . "</td></tr></table>
<br>

<form method=\"post\">
<input type=\"hidden\" name=\"confirm\" value=\"yes\">
<input type=\"submit\" name=\"submit\" value=\"Yes, Delete It\">
</form>
<form method=\"post\" action=\"list-links.php\">
<input type=\"submit\" value=\"Cancel\"></form>
";


 }
mysql_close;
include('adminfooter.php');
?>