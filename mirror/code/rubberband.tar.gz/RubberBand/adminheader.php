<?


// ADMIN HEADER


include('config.php');





function RedirectTo ($the_redirect_url) {
header("Location:".$the_redirect_url);
exit();
}


session_start();


//check to make sure the session variable is registered

if (!session_is_registered('username')){
    //the session variable isn't registered, send them back to the login page
    RedirectTo($admin_url . "index.html");
}


echo "" .
"<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"
  \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">

<html>

<head>
  <title>Admin</title>
<script language=\"javascript\">
function showdetails(showid) {
    var showcall = \"show-details.php?z=\" + showid;
    window.open(showcall, 'showdetails', 'width=310,height=200,menubar=no,location=no,scrollbars=yes');
}
function newsdetails(newsid) {
    var newscall = \"news-details.php?z=\" + newsid;
    window.open(newscall, 'newsdetails', 'width=340,height=400,menubar=no,location=no,scrollbars=yes');
}
function storydetails(storyid) {
    var storycall = \"story-details.php?z=\" + storyid;
    window.open(storycall, 'storydetails', 'width=400,height=425,menubar=no,location=no,scrollbars=yes');
}
function albumdetails(albumid) {
    var albumcall = \"album-details.php?z=\" + albumid;
    window.open(albumcall, 'albumdetails', 'width=530,height=400,menubar=no,location=no,scrollbars=yes');
}
function editlyrics(songid) {
     var editcall = \"edit-lyrics.php?song=\" + songid;
    window.open(editcall, 'editlyrics', 'width=530,height=400,menubar=no,location=no,scrollbars=yes');
}
function editmp3(songid) {
     var editcall = \"upload-mp3.php?song=\" + songid;
    window.open(editcall, 'editmp3', 'width=530,height=400,menubar=no,location=no,scrollbars=yes');
}

function changetitle() {
    parent.document.title = \"Uploading... this could take a few...\";
}
</script>
<link rel=\"stylesheet\" type=\"text/css\" href=\"rubberband.css\" />
</head>
<body>";

if ($dodge != "yes") {
echo "<div style=\"width: 550px; position: absolute; top: 40px; left: 50%; margin-left: -275px;\"><h2><a href=\"index.php\" class=\"title\">rubber band</a>.</h2></div>
<div style=\"border: double 4px #772222; width: 550px; position: absolute; top: 65px; left: 50%; margin-left: -275px; padding: 15px;\">";
}


?>