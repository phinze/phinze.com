<?
include('adminheader.php');
echo "<h2>Delete User</h2>";

// CONNECT
$dbh=mysql_connect ("localhost", $db_user, $db_pass) or die ('I cannot connect to the database because: ' . mysql_error());
mysql_select_db ($db_name) or die( "Unable to select database");

if ($submit) {
// CHECK IF CONFIRMED AND DELETE
if ($confirm1 && $confirm2 && $confirm3 && md5($pass) == $realpass) {
if ($name != $username) {
// BOXES CHECKED and PASS CORRECT ; DELETE
$query = "DELETE FROM " . $pre . "_users WHERE Name=\"" . $name . "\"";
mysql_query($query);

echo "User successfully deleted.<br><br>
<a href=\"list-users.php\">Back to users</a>.";
} else {
// TRYING TO DELETE SELF
echo "You cannot delete yourself.<br><br>
<a href=\"list-users.php\">Back to users</a>.";
}

} else {
// BOXES NOT CHECKED; RETURN
echo "All three boxes must be checked and password entered to confirm deletion of this show.<br><br>
<a href=\"javascript: history.back()\">Go back and try again</a>.";
}
} else {
// CONFIRM DELETION
$query = "SELECT * FROM " . $pre . "_users WHERE Name=\"" . $name . "\"";
$result = mysql_query($query);

$realpass = mysql_result($result,0,"Pass");

echo "<b>Are you sure you want to delete this user?</b><br><br>
<span style=\"font-size: 16px; font-weight: bold;\">" . $name . "</span>
<br>
<form method=\"post\">
<b>Check all three boxes and enter user's password to confirm.</b>
<input type=\"checkbox\" name=\"confirm1\" value=\"1\"> --
<input type=\"checkbox\" name=\"confirm2\" value=\"2\"> --
<input type=\"checkbox\" name=\"confirm3\" value=\"3\"><br>
<input type=\"text\" name=\"pass\" size=\"25\">
<input type=\"hidden\" name=\"realpass\" value=\"" . $realpass . "\"><br><br>
<input type=\"submit\" name=\"submit\" value=\"Delete\">
</form>
<form method=\"post\" action=\"list-users.php\">
<input type=\"submit\" value=\"Cancel\"></form>
";


 }
mysql_close;
include('adminfooter.php');
?>