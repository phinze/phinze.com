<?
include('adminheader.php');
echo "<h2>Shows</h2>";

// CONNECT
$dbh=mysql_connect ("localhost", $db_user, $db_pass) or die ('I cannot connect to the database because: ' . mysql_error());
mysql_select_db ($db_name) or die( "Unable to select database");

$query = "SELECT * FROM " . $pre . "_shows ORDER BY datetime";
$result = mysql_query($query);
$totalnum = mysql_numrows($result);

echo "<table border=1 cellspacing=1 cellpadding=1>
<tr><td><b>Date</b></td><td><b>Venue Name</b></td><td><b>Time</b></td><td><b>Price</b></td><td>&nbsp;</td></tr>";

$i=0; while ($i < $totalnum) {
$datetime = mysql_result($result,$i,"datetime");
$month = substr($datetime,0,2);
$date = substr($datetime,2,2);
$hour = substr($datetime,4,2);
$minute = substr($datetime,6,2);
$ampm = "am";
if ($hour > 12) {$hour = $hour - 12; $ampm = "pm";} // Return to 12-hour time
if (substr($month,0,1) == "0") {$month = substr($month,1,1);} // Remove leading zeros for array
if (substr($hour,0,1) == "0") {$hour = substr($hour,1,1);} // Remove leading zeros from hour

echo "<tr>
<td>" . $month . "-" . $date . "</td>
<td><a href=\"javascript: showdetails('" . mysql_result($result,$i,"id") . "');\" title=\"View show details\">" . mysql_result($result,$i,"name") . "</a></td>
<td>" . $hour . ":" . $minute . " " . $ampm . "</td>
<td>" . mysql_result($result,$i,"price") . "</td>
<td><a href=\"edit-show.php?id=" . mysql_result($result,$i,"id") . "\">Edit</a> <a href=\"delete-show.php?id=" . mysql_result($result,$i,"id") . "\">Delete</a></td>
</tr>";
$i++;
}
echo "</table>

<br><form method=\"post\" action=\"add-show.php\">
<input type=\"submit\" value=\"Add Show\"></form>
<br>
<br><form method=\"post\" action=\"latest-show.php\">
<input type=\"submit\" value=\"Update Latest Show\"></form>";

mysql_close;
include('adminfooter.php');
?>