<?
$dodge = "yes";
include('adminheader.php');

// CONNECT
$dbh=mysql_connect ("localhost", $db_user, $db_pass) or die ('I cannot connect to the database because: ' . mysql_error());
mysql_select_db ($db_name) or die( "Unable to select database");

$query = "SELECT * FROM " . $pre . "_shows ORDER BY datetime LIMIT 1";
$result = mysql_query($query);

$datetime = mysql_result($result,0,"datetime");
$month = substr($datetime,0,2);
$date = substr($datetime,2,2);
$hour = substr($datetime,4,2);
$minute = substr($datetime,6,2);
$ampm = "am";
if ($hour > 12) {$hour = $hour - 12; $ampm = "pm";} // Return to 12-hour time
if (substr($month,0,1) == "0") {$month = substr($month,1,1);} // Remove leading zeros for array
if (substr($hour,0,1) == "0") {$hour = substr($hour,1,1);} // Remove leading zeros from hour

// build string to write into file

$writeme =  "<b>" . mysql_result($result,0,"name") . "</b><br>
" . $month . " - " . $date . "<br>
" . $hour . ":" . $minute . " " . $ampm . "<br>
" . mysql_result($result,0,"price");

if ($result) {
$fp = fopen ("../nextshow.txt", "w");
fwrite ($fp, $writeme);
fclose ($fp);}


mysql_close;
include('adminfooter.php');
?>