<?
include('config.php');
error_reporting(0);

//check that the user is calling the page from the login form and not accessing it directly
//and redirect back to the login form if necessary
if (!isset($username) || !isset($password)) {
echo "<a href=\"" . $admin_url . "index.html\">Click here to login</a>.";
}
//check that the form fields are not empty, and redirect back to the login page if they are
elseif (empty($username) || empty($password)) {
echo "<a href=\"" . $admin_url . "index.html\">Click here to login</a>.";
}
else{

//convert the field values to simple variables

//add slashes to the username and md5() the password
$user = addslashes($username);
$pass = md5($password);

//connet to the database
$dbh=mysql_connect ("localhost", $db_user, $db_pass) or die ('I cannot connect to the database because: ' . mysql_error());
mysql_select_db($db_name) or die ("Couldn't select the database.");
$result=mysql_query("select * from " . $pre . "_users where Name='" . $user . "' AND Pass='" . $pass . "'", $dbh);

//capitalize username
$username = ucwords($username);

//check that at least one row was returned
$rowCheck = mysql_num_rows($result);
if($rowCheck > 0){
while($row = mysql_fetch_array($result)){

    //start the session and register a variable

    session_start();
    session_register('username');

    //successful login code will go here...
    echo 'You are now logged in!<br><br>Please wait while you are redirected...';

    //we will redirect the user to another page where we will make sure they're logged in
    header( "Location: " . $admin_url . "index.php" ); // PHP Redirect
    // HTML and then JavaScript redirect
    echo "
    <html>
    <head>
    <meta http-equiv=\"refresh\" content=\"0; url=" . $admin_url . "index.php\">
    </head>
    <body>
    <script language=\"JavaScript\">
    <!-- Begin
    location.replace('" . $admin_url . "index.php');
    // End -->
	</script>
    </body>
    </html>";
    }

    }
    else {

    //if nothing is returned by the query, unsuccessful login code goes here...
    echo "
    <html>
    <head>
    <meta http-equiv=\"refresh\" content=\"2; url=" . $admin_url . "index.php\">
    </head>
    <body>
    Incorrect login name or password. Please try again. Redirect in 2 seconds.
    </body>
    </html>
    ";
    }
    }
?>