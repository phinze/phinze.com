<?
include('adminheader.php');
echo "<h2>Edit Show</h2>";

// CONNECT
$dbh=mysql_connect ("localhost", $db_user, $db_pass) or die ('I cannot connect to the database because: ' . mysql_error());
mysql_select_db ($db_name) or die( "Unable to select database");

if ($submit) {

if ($name == "" || $name == "Venue Name" || $date == "" || $hour == "" || $minute == "" || $location == "" || $price == "") {
// FIELDS MISSING (YOU SUCK)

if (substr($month,0,1) == "0") {$month = substr($month,1,1);} // Remove leading zeros for array
$month_selected[$month] = "selected";
$ampm_selected[$ampm] = "checked";

echo "You forgot to fill in all the fields.
<br><br>
<form method=\"post\">
<input type=\"hidden\" name=\"id\" value=\"" . $id . "\">
<b>Name:</b> <input name=\"name\" value=\"" . $name . "\" size=\"25\"><br>
<b>Venue URL:</b> <input name=\"namelink\" value=\"" . $namelink . "\" size=\"25\"> <font color=red>[optional]</font><br>
<b>Month:</b>&nbsp;&nbsp;<select name=\"month\">
<option name=\"month\" value=\"01\" " . $month_selected[1] . ">January</option>
<option name=\"month\" value=\"02\" " . $month_selected[2] . ">February</option>
<option name=\"month\" value=\"03\" " . $month_selected[3] . ">March</option>
<option name=\"month\" value=\"04\" " . $month_selected[4] . ">April</option>
<option name=\"month\" value=\"05\" " . $month_selected[5] . ">May</option>
<option name=\"month\" value=\"06\" " . $month_selected[6] . ">June</option>
<option name=\"month\" value=\"07\" " . $month_selected[7] . ">July</option>
<option name=\"month\" value=\"08\" " . $month_selected[8] . ">August</option>
<option name=\"month\" value=\"09\" " . $month_selected[9] . ">September</option>
<option name=\"month\" value=\"10\" " . $month_selected[10] . ">October</option>
<option name=\"month\" value=\"11\" " . $month_selected[11] . ">November</option>
<option name=\"month\" value=\"12\" " . $month_selected[12] . ">December</option>
</select>&nbsp;&nbsp;<b>Date:</b>&nbsp;&nbsp;<input type=\"text\" name=\"date\" value=\"" . $date . "\" style=\"width: 20px;\" maxlength=2><BR>
<b>Time:</b>&nbsp;&nbsp;<input type=\"text\" name=\"hour\" value=\"" . $hour . "\" style=\"width: 20px; text-align:right;\" maxlength=2>&nbsp;&nbsp;:&nbsp;&nbsp;<input type=\"text\" name=\"minute\" value=\"" . $minute . "\" style=\"width: 20px;\" maxlength=2>&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"radio\" name=\"ampm\" value=\"1\" " . $ampm_selected[1] . "> AM &nbsp;&nbsp;<input type=\"radio\" name=\"ampm\" value=\"2\"  " . $ampm_selected[2] . "> PM<BR>
<br>
<b>Where (include address):</b><br>
&nbsp;&nbsp;&nbsp;&nbsp;Timmy's House&lt;br&gt;<br>
&nbsp;&nbsp;&nbsp;&nbsp;123 Fake St.&lt;br&gt;<br>
&nbsp;&nbsp;&nbsp;&nbsp;Corner of Bluemound and Fake<br>
<TEXTAREA name=\"location\" rows=4 cols=30>" . $location . "</TEXTAREA><BR>
<b>With (other bands):</b> <font color=red>[optional]</font><br>
&nbsp;&nbsp;&nbsp;&nbsp;KISS&lt;br&gt;<br>
&nbsp;&nbsp;&nbsp;&nbsp;AC/DC&lt;br&gt;<br>
&nbsp;&nbsp;&nbsp;&nbsp;The Scumfucks<br>
<TEXTAREA name=\"others\" rows=4 cols=30>" . $others . "</TEXTAREA><BR>
<b>Price:</b>&nbsp;&nbsp;<INPUT name=\"price\" type=\"text\" value=\"" . $price . "\" size=\"5\">&nbsp;&nbsp;$4<BR>
<INPUT name=\"submit\" type=\"submit\" value=\"Try Again\">
</FORM>";


} else {
// FIELDS NOT MISSING (YOU WIN)

if ($ampm == "2") {$hour = $hour + 12;}   // If time is PM, add 12 to hours

while(strlen($date)!=2)$date="0".$date;      // Add leading zeros to #'s < 10
while(strlen($hour)!=2)$hour="0".$hour;
while(strlen($minute)!=2)$minute="0".$minute;
$datetime = $month . $date . $hour . $minute;   // Concatenate DateTime string

$query = "UPDATE " . $pre . "_shows SET Name='" . $name . "', NameLink='" . $namelink . "', DateTime='" . $datetime . "', Location='" . $location . "', Others='" . $others . "', Price='" . $price . "' WHERE ID=" . $id;
mysql_query($query);

echo "Changes saved.<br><br>
<a href=\"list-shows.php\">Back to shows</a>.";
}

} else {

$query = "SELECT * FROM " . $pre . "_shows WHERE ID=" . $id;
$result = mysql_query($query);

$name = mysql_result($result,0,"name");
$namelink = mysql_result($result,0,"namelink");
$location = mysql_result($result,0,"location");
$others = mysql_result($result,0,"others");
$price = mysql_result($result,0,"price");

$datetime = mysql_result($result,0,"datetime");
$month = substr($datetime,0,2);
$date = substr($datetime,2,2);
$hour = substr($datetime,4,2);
$minute = substr($datetime,6,2);

$ampm = 1;
if ($hour > 12) {$hour = $hour - 12; $ampm = 2;} // Return to 12-hour time
if (substr($month,0,1) == "0") {$month = substr($month,1,1);} // Remove leading zeros for array

$month_selected[$month] = "selected";
$ampm_selected[$ampm] = "checked";

echo "Edit whatever you want.
<br><br>
<form method=\"post\">
<input type=\"hidden\" name=\"id\" value=\"" . $id . "\">
<b>Name:</b> <input name=\"name\" value=\"" . $name . "\" size=\"25\"><br>
<b>Venue URL:</b> <input name=\"namelink\" value=\"" . $namelink . "\" size=\"25\"> <font color=red>[optional]</font><br>
<b>Month:</b>&nbsp;&nbsp;<select name=\"month\">
<option name=\"month\" value=\"01\" " . $month_selected[1] . ">January</option>
<option name=\"month\" value=\"02\" " . $month_selected[2] . ">February</option>
<option name=\"month\" value=\"03\" " . $month_selected[3] . ">March</option>
<option name=\"month\" value=\"04\" " . $month_selected[4] . ">April</option>
<option name=\"month\" value=\"05\" " . $month_selected[5] . ">May</option>
<option name=\"month\" value=\"06\" " . $month_selected[6] . ">June</option>
<option name=\"month\" value=\"07\" " . $month_selected[7] . ">July</option>
<option name=\"month\" value=\"08\" " . $month_selected[8] . ">August</option>
<option name=\"month\" value=\"09\" " . $month_selected[9] . ">September</option>
<option name=\"month\" value=\"10\" " . $month_selected[10] . ">October</option>
<option name=\"month\" value=\"11\" " . $month_selected[11] . ">November</option>
<option name=\"month\" value=\"12\" " . $month_selected[12] . ">December</option>
</select>&nbsp;&nbsp;<b>Date:</b>&nbsp;&nbsp;<input type=\"text\" name=\"date\" value=\"" . $date . "\" style=\"width: 20px;\" maxlength=2><BR>
<b>Time:</b>&nbsp;&nbsp;<input type=\"text\" name=\"hour\" value=\"" . $hour . "\" style=\"width: 20px; text-align:right;\" maxlength=2>&nbsp;&nbsp;:&nbsp;&nbsp;<input type=\"text\" name=\"minute\" value=\"" . $minute . "\" style=\"width: 20px;\" maxlength=2>&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"radio\" name=\"ampm\" value=\"1\" " . $ampm_selected[1] . "> AM &nbsp;&nbsp;<input type=\"radio\" name=\"ampm\" value=\"2\"  " . $ampm_selected[2] . "> PM<BR>
<br>
<b>Where (include address):</b><br>
&nbsp;&nbsp;&nbsp;&nbsp;Timmy's House&lt;br&gt;<br>
&nbsp;&nbsp;&nbsp;&nbsp;123 Fake St.&lt;br&gt;<br>
&nbsp;&nbsp;&nbsp;&nbsp;Corner of Bluemound and Fake<br>
<textarea name=\"location\" rows=4 cols=30>" . $location . "</textarea><br>
<b>With (other bands):</b> <font color=red>[optional]</font><br>
&nbsp;&nbsp;&nbsp;&nbsp;KISS&lt;br&gt;<br>
&nbsp;&nbsp;&nbsp;&nbsp;AC/DC&lt;br&gt;<br>
&nbsp;&nbsp;&nbsp;&nbsp;The Scumfucks<br>
<textarea name=\"others\" rows=4 cols=30>" . $others . "</textarea><br>
<b>Price:</b>&nbsp;&nbsp;<INPUT name=\"price\" type=\"text\" value=\"" . $price . "\" size=\"5\">&nbsp;&nbsp;$4<BR>
<input name=\"submit\" type=\"submit\" value=\"Save Changes\"></form>
<form method=\"post\" action=\"list-shows.php\">
<input type=\"submit\" value=\"Cancel\"></form>
";
}

mysql_close;
include('adminfooter.php');
?>