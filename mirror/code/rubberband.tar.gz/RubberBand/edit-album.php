<?
include('adminheader.php');
error_reporting(E_ERROR | E_PARSE);
echo "<h2>Edit Album</h2>";

// CONNECT
$dbh=mysql_connect ("localhost", $db_user, $db_pass) or die ('I cannot connect to the database because: ' . mysql_error());
mysql_select_db ($db_name) or die( "Unable to select database");

if ($submit) {

// UPDATE WITH NEW INFO

$query = "UPDATE " . $pre . "_albums SET Album='" . $album . "', Description='" . $description . "' WHERE ID=" . $id;
mysql_query($query);

$i = 1;
while ($i < $tracks + 1) {
if ($i == 1) {$new_title = $title1; $new_featuring = $featuring1;}
elseif ($i == 2) {$new_title = $title2; $new_featuring = $featuring2;}
elseif ($i == 3) {$new_title = $title3; $new_featuring = $featuring3;}
elseif ($i == 4) {$new_title = $title4; $new_featuring = $featuring4;}
elseif ($i == 5) {$new_title = $title5; $new_featuring = $featuring5;}
elseif ($i == 6) {$new_title = $title6; $new_featuring = $featuring6;}
elseif ($i == 7) {$new_title = $title7; $new_featuring = $featuring7;}
elseif ($i == 8) {$new_title = $title8; $new_featuring = $featuring8;}
elseif ($i == 9) {$new_title = $title9; $new_featuring = $featuring9;}
elseif ($i == 10) {$new_title = $title10; $new_featuring = $featuring10;}
elseif ($i == 11) {$new_title = $title11; $new_featuring = $featuring11;}
elseif ($i == 12) {$new_title = $title12; $new_featuring = $featuring12;}
elseif ($i == 13) {$new_title = $title13; $new_featuring = $featuring13;}
elseif ($i == 14) {$new_title = $title14; $new_featuring = $featuring14;}
elseif ($i == 15) {$new_title = $title15; $new_featuring = $featuring15;}
else {$noupdate = 1;}

if ($noupdate != 1) {
$query = "UPDATE " . $pre . "_songs SET Title='" . $new_title . "', Featuring='" . $new_featuring . "' WHERE Parent=" . $id . " AND TrackNum=" . $i;
mysql_query($query);}

$i++;}

echo "Changes saved.<br><br>
<a href=\"list-albums.php\">Back to albums</a>.";

} else {

$query = "SELECT * FROM " . $pre . "_albums WHERE ID=" . $id;
$result1 = mysql_query($query);

$album = mysql_result($result1,0,"album");
$description = mysql_result($result1,0,"description");

echo "Edit whatever you want.
<form method=\"post\">

<b>Album Title:</b> <input name=\"album\" size=\"40\" value=\"" . $album . "\"><br>
<b>Description:</b><br><textarea name=\"description\" rows=12 cols=70>" . $description . "</textarea><br>";

$query = "SELECT * FROM " . $pre . "_songs WHERE Parent=" . $id . " ORDER BY TrackNum";
$result2 = mysql_query($query);
$totalnum = mysql_numrows($result2);

$i = 0; echo "<table class=\"none\" cellspacing=1 cellpadding=1><tr><td><b>#</b></td><td><b>Title</b></td><td><b>Written By:</b></td></tr>";
while ($i < $totalnum) {
echo "<tr>
<td>" . mysql_result($result2,$i,"tracknum") . "</td>
<td><input name=\"title" . mysql_result($result2,$i,"tracknum") . "\" value=\"" . mysql_result($result2,$i,"title") . "\" size=35></td>
<td><input name=\"featuring" . mysql_result($result2,$i,"tracknum") . "\" value=\"" . mysql_result($result2,$i,"featuring") . "\" size=35></td>
";


echo "<td><a href=\"javascript:editlyrics(" . mysql_result($result2,$i,"id") . ")\">Lyrics</a></td>";
echo "<td><a href=\"javascript:editmp3(" . mysql_result($result2,$i,"id") . ")\">mp3</a></td>";
echo "</tr>";
$i++;}

echo "</table>
<input type=\"hidden\" name=\"tracks\" value=\"" . $totalnum . "\">
<input name=\"submit\" type=\"submit\" value=\"Save Changes\" class=\"button\">
</form>
<form method=\"post\" action=\"list-albums.php\">
<input type=\"submit\" value=\"Cancel\" class=\"button\"></form>";
}

mysql_close;
include('adminfooter.php');
?>