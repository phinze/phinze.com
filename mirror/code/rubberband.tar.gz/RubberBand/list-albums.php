<?
include('adminheader.php');
echo "<h2>Albums</h2>";

// CONNECT
$dbh=mysql_connect ("localhost", $db_user, $db_pass) or die ('I cannot connect to the database because: ' . mysql_error());
mysql_select_db ($db_name) or die( "Unable to select database");

$query = "SELECT * FROM " . $pre . "_albums ORDER BY ordernum";
$result = mysql_query($query);
$totalnum = mysql_numrows($result);

echo "<table border=1 cellspacing=1 cellpadding=1>
<tr><td><b>Album</b></td><td width=125>&nbsp;</td></tr>";

$i=0; while ($i < $totalnum) {
echo "<tr>
<td><a href=\"javascript: albumdetails('" . mysql_result($result,$i,"id") . "');\" title=\"View post\">" . mysql_result($result,$i,"album") . "</a></td>
<td><a href=\"edit-album.php?id=" . mysql_result($result,$i,"id") . "\">Edit</a> <a href=\"delete-album.php?id=" . mysql_result($result,$i,"id") . "\">Delete</a></td>
</tr>";
$i++;
}
echo "</table>

<br><form method=\"post\" action=\"add-album.php\">
Number of Tracks: <input type=\"text\" size=\"2\" maxlength=\"2\" name=\"tracks\" value=\"5\"><br>
<input type=\"submit\" value=\"Create New Album\">
</form>";

mysql_close;
include('adminfooter.php');
?>