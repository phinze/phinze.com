<?
include('adminheader.php');
echo "<h2>Edit Bios</h2>";

$oldpattern = array("<EM>","</EM>", "<STRONG>","</STRONG>", "<U>","</U>", "[/color]","[color=","]","<P>","</P>","&lt;br&gt;");
$newreplace = array("<i>","</i>", "<b>","</b>", "<u>","</u>", "</font>","<font color=\"","\">","","<br><br>","<br>");


if ($submit) {

$text_save = str_replace($oldpattern,$newreplace,$bios_text);

$fp = fopen ("../bios.txt", "w");
fwrite ($fp, $text_save);
fclose ($fp);

}
// display form

$fp = fopen("../bios.txt", "r");
$bio_load = fread($fp, filesize("../bios.txt"));
fclose ($fp);
$bio_load = str_replace($newreplace,$oldpattern,$bio_load);

$oldpattern2 = array("\"");
$newreplace2 = array("&quot;");

$bio_load = str_replace($oldpattern2,$newreplace2,$bio_load);
$bio_lines = split("[\n\r]", $bio_load);
?>

<form onsubmit="copyValue(this)" method="post">
<textarea id=EditorValue name="bios_text" style="display: none;"></textarea>

<iframe width=500 height=300 id=myEditor style="font-family: arial;"></iframe><br>

<script>
function copyValue(f) {
    f.elements.EditorValue.value = "" + myEditor.document.body.innerHTML + "";
  }

    function makeStyle($style) {
    // Get a text range for the selection
    var tr = frames.myEditor.document.selection.createRange()
    // Execute the bold command
    tr.execCommand($style)
    // Reselect and give the focus back to the editor
    tr.select()
    frames.myEditor.focus()
  }

  frames.myEditor.document.designMode = "On";

<?
if ($bio_load) {
foreach ($bio_lines as $bio_line) {
echo "myEditor.document.write(\"" . stripslashes($bio_line) . "\")
";
}
}
?>
</script>

<input unselectable="On" type="button" onclick='makeStyle("Bold")' value="B" style="font-weight: 900">
<input unselectable="On" type="button" onclick='makeStyle("Italic")' value="I" style="font-style: italic; font-weight:bold">
<input unselectable="On" type="button" onclick='makeStyle("Underline")' value="U" style="text-decoration: underline;font-weight: bold">

<input type="submit" name="submit" value="Submit">
</form>

<?
include('adminfooter.php');
?>