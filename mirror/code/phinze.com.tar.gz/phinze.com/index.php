<?php
require_once('common/ContentDispatcher.php');
$cd = new ContentDispatcher();
$cd->displayPage();
?>
