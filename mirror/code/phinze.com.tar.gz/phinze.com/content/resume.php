<?php $pagetitle = "resume"; ?>
<h2>Resume</h2>
<p>It would be  silly for me to manually convert the data in my resume from 
LaTeX into XHTML, so until I write a script to do that, I'll just provide the 
<a href="<?php echo $this->getHomeUrl() ?>extras/phinze_resume.pdf">pdf version of my 
resume</a> and my <a href="http://www.linkedin.com/in/phinze">LinkedIn 
profile</a>.</p>
