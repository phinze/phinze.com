<?php $pagetitle=""; ?>
<h2>A Convergence of Distractions</h2>
<p>My name is Paul Hinze and this is where I maintain a small set of personal information: there is a little about my life and academics, but my focus is on creating a humble showcase of my past, current, and future projects.</p>
<p>I've gotten to the point where I could swear that I've done some really neat things with computers over the course of my life, but when I get the inevitable "Well, like what?" question, I'm left with only words, hand gestures, and assurances of how cool this or that thing was.  Given my generally shaky memory, the ratio of imaginative filler in these stories only increases the longer it's been since I actually worked on a given project.</p>
<p>Here is my solution to that problem.</p>
